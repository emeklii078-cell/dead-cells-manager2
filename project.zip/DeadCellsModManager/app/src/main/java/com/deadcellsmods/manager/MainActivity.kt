package com.deadcellsmods.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private lateinit var mm: ModManager
    private var state by mutableIntStateOf(0)

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> state = Shell.state() }
    private val binderListener = Shizuku.OnBinderReceivedListener { state = Shell.state() }
    private val deadListener = Shizuku.OnBinderDeadListener { state = Shell.state() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mm = ModManager(this)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListener(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        state = Shell.state()
        setContent { MaterialTheme { App() } }
    }

    override fun onResume() { super.onResume(); state = Shell.state() }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun App() {
        val scope = rememberCoroutineScope()
        var mods by remember { mutableStateOf(mm.list()) }
        var msg by remember { mutableStateOf("") }
        var target by remember { mutableStateOf(mm.targetDir) }
        var busy by remember { mutableStateOf(false) }

        fun task(block: () -> String) {
            scope.launch {
                busy = true
                msg = withContext(Dispatchers.IO) {
                    try { block() } catch (e: Throwable) { "Hata: ${e.message}" }
                }
                mods = mm.list(); busy = false
            }
        }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) task { "“${mm.import(uri)}” içe aktarıldı" }
        }

        Scaffold(topBar = { TopAppBar(title = { Text("Dead Cells Mod Yöneticisi") }) }) { pad ->
            Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (state) {
                    0 -> Text("Shizuku çalışmıyor. Shizuku uygulamasını açıp başlat, sonra buraya dön.")
                    1 -> Button(onClick = { Shizuku.requestPermission(1) }) { Text("Shizuku iznini ver") }
                    else -> Text("Shizuku hazır ✓")
                }
                OutlinedTextField(
                    value = target,
                    onValueChange = { target = it; mm.targetDir = it },
                    label = { Text("Oyun hedef klasörü") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Mod içe aktar") }
                    OutlinedButton(onClick = {
                        packageManager.getLaunchIntentForPackage(ModManager.GAME_PKG)?.let { startActivity(it) }
                            ?: kotlin.run { msg = "Dead Cells yüklü değil" }
                    }) { Text("Oyunu başlat") }
                }
                if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
                if (mods.isEmpty()) Text("Henüz mod yok. .zip veya .pak dosyası içe aktar.")
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(mods, key = { it.name }) { mod ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(mod.name, style = MaterialTheme.typography.titleMedium)
                                    Text("${mod.files.size} dosya", style = MaterialTheme.typography.bodySmall)
                                }
                                Switch(
                                    checked = mod.enabled,
                                    enabled = !busy && state == 2,
                                    onCheckedChange = { on ->
                                        task { if (on) mm.enable(mod.name) else mm.disable(mod.name) }
                                    }
                                )
                                TextButton(enabled = !busy && state == 2, onClick = { task { mm.delete(mod.name) } }) { Text("Sil") }
                            }
                        }
                    }
                }
            }
        }
    }
}
