package com.deadcellsmods.manager

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.util.zip.ZipInputStream

data class Mod(val name: String, val files: List<String>, val enabled: Boolean)

class ModManager(private val ctx: Context) {
    companion object {
        const val GAME_PKG = "com.playdigious.deadcells.mobile"
        const val DEFAULT_TARGET = "/storage/emulated/0/Android/data/$GAME_PKG/files"
    }

    private val root: File = ctx.getExternalFilesDir(null)!!
    private val modsDir = File(root, "mods").apply { mkdirs() }
    private val backupDir = File(root, "backup").apply { mkdirs() }
    private val prefs = ctx.getSharedPreferences("mods", Context.MODE_PRIVATE)

    var targetDir: String
        get() = prefs.getString("target", DEFAULT_TARGET)!!
        set(v) { prefs.edit().putString("target", v.trim().trimEnd('/')).apply() }

    private fun enabledSet(): Set<String> = prefs.getStringSet("enabled", emptySet())!!.toSet()
    private fun setEnabled(name: String, on: Boolean) {
        val s = enabledSet().toMutableSet()
        if (on) s.add(name) else s.remove(name)
        prefs.edit().putStringSet("enabled", s).apply()
    }

    private fun filesOf(dir: File) =
        dir.walkTopDown().filter { it.isFile }.map { it.relativeTo(dir).path }.toList()

    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    fun list(): List<Mod> {
        val en = enabledSet()
        return (modsDir.listFiles() ?: emptyArray())
            .filter { it.isDirectory }.sortedBy { it.name }
            .map { Mod(it.name, filesOf(it), it.name in en) }
    }

    /** .zip ise açar, değilse (.pak vb.) olduğu gibi kopyalar. */
    fun import(uri: Uri): String {
        var display = "mod"
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) display = c.getString(i)
        }
        val base = display.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._ -]"), "_")
        if (base in enabledSet()) disable(base)
        val dest = File(modsDir, base)
        dest.deleteRecursively(); dest.mkdirs()
        ctx.contentResolver.openInputStream(uri)!!.use { input ->
            if (display.endsWith(".zip", true)) {
                ZipInputStream(input).use { zis ->
                    var e = zis.nextEntry
                    while (e != null) {
                        val out = File(dest, e.name)
                        if (!out.canonicalPath.startsWith(dest.canonicalPath + File.separator))
                            throw SecurityException("Geçersiz zip girdisi: ${e.name}")
                        if (e.isDirectory) out.mkdirs()
                        else { out.parentFile?.mkdirs(); out.outputStream().use { zis.copyTo(it) } }
                        e = zis.nextEntry
                    }
                }
            } else {
                File(dest, display).outputStream().use { input.copyTo(it) }
            }
        }
        return base
    }

    fun enable(name: String): String {
        val src = File(modsDir, name)
        val sb = StringBuilder("set -e\n")
        for (rel in filesOf(src)) {
            val t = "$targetDir/$rel"
            val b = "${backupDir.absolutePath}/$name/$rel"
            sb.append("mkdir -p ${q(File(t).parent!!)}\n")
            // orijinal dosyayı yalnızca bir kez yedekle
            sb.append("if [ -e ${q(t)} ] && [ ! -e ${q(b)} ]; then mkdir -p ${q(File(b).parent!!)}; cp -f ${q(t)} ${q(b)}; fi\n")
            sb.append("cp -f ${q(File(src, rel).absolutePath)} ${q(t)}\n")
        }
        val (code, out) = Shell.run(sb.toString())
        return if (code == 0) { setEnabled(name, true); "“$name” etkinleştirildi" } else "Hata: $out"
    }

    fun disable(name: String): String {
        val src = File(modsDir, name)
        val sb = StringBuilder("set -e\n")
        for (rel in filesOf(src)) {
            val t = "$targetDir/$rel"
            val b = "${backupDir.absolutePath}/$name/$rel"
            sb.append("if [ -e ${q(b)} ]; then cp -f ${q(b)} ${q(t)}; else rm -f ${q(t)}; fi\n")
        }
        val (code, out) = Shell.run(sb.toString())
        return if (code == 0) { setEnabled(name, false); "“$name” devre dışı bırakıldı" } else "Hata: $out"
    }

    fun delete(name: String): String {
        if (name in enabledSet()) {
            val r = disable(name)
            if (r.startsWith("Hata")) return r
        }
        File(modsDir, name).deleteRecursively()
        File(backupDir, name).deleteRecursively()
        return "“$name” silindi"
    }
}
