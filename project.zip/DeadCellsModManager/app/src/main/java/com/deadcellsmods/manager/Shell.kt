package com.deadcellsmods.manager

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object Shell {
    /** 0 = Shizuku çalışmıyor, 1 = izin yok, 2 = hazır */
    fun state(): Int = try {
        if (!Shizuku.pingBinder()) 0
        else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) 2
        else 1
    } catch (e: Throwable) { 0 }

    /** Komutu shell (adb) yetkisiyle çalıştırır. */
    fun run(script: String): Pair<Int, String> {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "$script 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val code = p.waitFor()
        return code to out.trim()
    }
}
