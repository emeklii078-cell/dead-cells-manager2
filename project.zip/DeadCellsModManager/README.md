# Dead Cells Mod Yöneticisi (Android 13+)

## Kullanım
1. Telefona **Shizuku** kur ve başlat (Geliştirici seçenekleri → Kablosuz hata ayıklama ile).
2. Bu uygulamayı kur, aç, Shizuku iznini ver.
3. "Mod içe aktar" → .zip veya .pak seç.
4. Anahtarı aç: mod dosyaları hedef klasöre kopyalanır, orijinaller yedeklenir.
   Kapatınca orijinaller geri yüklenir.

## APK derleme
- PC: Android Studio ile klasörü aç → Build → Build APK.
- Telefondan: klasörü GitHub'a yükle → Actions → "Build APK" → Run workflow → artifact'ı indir.

## Önemli
- Hedef klasör varsayılan: /storage/emulated/0/Android/data/com.playdigious.deadcells.mobile/files
  Oyunun modları gerçekten oradan okuyup okumadığı doğrulanmadı; uygulamada değiştirilebilir.
- Mod zip'inin içindeki klasör yapısı hedef klasöre göre aynen korunur.
